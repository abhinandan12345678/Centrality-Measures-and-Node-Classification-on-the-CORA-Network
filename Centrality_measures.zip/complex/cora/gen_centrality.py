from collections import deque, defaultdict

# Creation of Adjacency List of the Graph
def create_adj_list_from_cites_file(file_path):
    adj_list = {}
    with open(file_path, 'r') as file:
        for line in file:
            target, source = line.strip().split()
            target = int(target)
            source = int(source)
            if source not in adj_list:
                adj_list[source] = []
            if target not in adj_list:
                adj_list[target] = []

            adj_list[source].append(target)

    return adj_list

# Adjust the nodes with zero outdegree
def adjust_adj_list_for_zero_outdegree_nodes(adj_list):
    no_outgoing = [node for node, targets in adj_list.items() if len(targets) == 0]

    for node in no_outgoing:
        for source, targets in adj_list.items():
            if node in targets:
                if node not in adj_list:
                    adj_list[node] = []
                adj_list[node].append(source)
    
    return adj_list

# Store the node ids in a list
def get_all_nodes_from_adj_list(adj_list):
    all_nodes_set = set()
    for source in adj_list.keys():
        all_nodes_set.add(source)

    for targets in adj_list.values():
        all_nodes_set.update(targets)

    all_nodes_list = list(all_nodes_set)
    return all_nodes_list

file_path = 'cora.cites'
adj_list_primal = create_adj_list_from_cites_file(file_path)
adj_list = adjust_adj_list_for_zero_outdegree_nodes(adj_list_primal)
all_nodes = get_all_nodes_from_adj_list(adj_list)

# Writing the graph in a .txt file
def write_sorted_graph_to_file(adj_list, output_file_path):
    with open(output_file_path, 'w+') as file:
        for source in sorted(adj_list.keys()):
            targets = sorted(adj_list[source])
            targets_str = ', '.join(map(str, targets))
            line = f"{source} -> {targets_str}\n"
            file.write(line)

output_file_path = 'C:\\Users\\ABHINANDAN\\Desktop\\complex\\cora\\centralities\\sorted_graph.txt'
write_sorted_graph_to_file(adj_list, output_file_path)

# Normal BFS for closeness centrality
def bfs(graph, start):
    queue = deque([(start, 0)])
    visited = {start: 0}
    
    while queue:
        current_node, distance = queue.popleft()
        for neighbor in graph[current_node]:
            if neighbor not in visited:
                visited[neighbor] = distance + 1
                queue.append((neighbor, distance + 1))
    
    return visited

# Calculate the shotest path from a node i to all other nodes except i
def find_all_shortest_paths(graph):
    all_nodes = set(graph.keys())
    for targets in graph.values():
        all_nodes.update(targets)

    all_paths = {}
    for source in graph:
        bfs_result = bfs(graph, source)
        paths = {}
        for target in all_nodes:
            if target != source:
                paths[target] = bfs_result.get(target, 10**9)
        all_paths[source] = paths
    return all_paths

all_shortest_paths = find_all_shortest_paths(adj_list)

# Closeness centrality calculation
def calculate_closeness_centrality(all_shortest_paths, total_nodes):
    centrality_values = {}
    for source, paths in all_shortest_paths.items():
        total_distance = sum(length for length in paths.values() if length != 10**9)
        if total_distance > 0:
            centrality_values[source] = round((total_nodes - 1) / total_distance, 6)
        else:
            centrality_values[source] = 0
    return centrality_values

centrality_values = calculate_closeness_centrality(all_shortest_paths, 2707)

sorted_nodes = sorted(centrality_values.items(), key=lambda x: x[1], reverse=False)

# Writing closeness centrality in a .txt file
closeness_file_path = 'C:\\Users\\ABHINANDAN\\Desktop\\complex\\cora\\centralities\\closeness.txt'
with open(closeness_file_path, 'w+') as file:
    for node, centrality in sorted_nodes:
        file.write(f"{node} {centrality}\n")

# Initializing pagerank matrix
def initialize_pagerank(graph):
    N = len(graph)
    return {node: 1/N for node in graph}

# Calculation of pagerank using power iteration method
def calculate_pagerank(graph, damping_factor=0.8, max_iterations=100, tol=1e-6):
    N = len(graph)
    pagerank = {node: 1/N for node in graph}
    outgoing_links = {node: len(targets) if len(targets) > 0 else N for node, targets in graph.items()}
    
    for iteration in range(max_iterations):
        new_pagerank = {}
        for node in graph:
            incoming_sum = sum(pagerank[neighbor] / outgoing_links[neighbor] for neighbor, targets in graph.items() if node in targets or outgoing_links[neighbor] == N)
            new_pagerank[node] = (1 - damping_factor) / N + damping_factor * incoming_sum
        
        if all(abs(new_pagerank[node] - pagerank[node]) < tol for node in graph):
            break
        pagerank = new_pagerank
    
    return pagerank

pagerank_values = calculate_pagerank(adj_list)

# Writing pagerank values in a .txt file 
pagerank_file_path = 'C:\\Users\\ABHINANDAN\\Desktop\\complex\\cora\\centralities\\pagerank.txt'
with open(pagerank_file_path, 'w+') as file:
    for node in sorted(pagerank_values):
        file.write(f"{node} {pagerank_values[node]:.6f}\n")

# BFS to find shortest paths for betweenness centrality
def bfs_shortest_paths(graph, start):
    queue = deque([[start]])
    visited = set()
    paths = defaultdict(list)
    shortest_path_length = {}

    while queue:
        path = queue.popleft()
        node = path[-1]

        if node not in visited:
            visited.add(node)
            for neighbor in graph[node]:
                new_path = list(path)
                new_path.append(neighbor)
                path_length = len(new_path) - 1

                if neighbor not in shortest_path_length or path_length <= shortest_path_length[neighbor]:
                    if neighbor in shortest_path_length and path_length < shortest_path_length[neighbor]:
                        paths[(start, neighbor)].clear()
                    shortest_path_length[neighbor] = path_length
                    paths[(start, neighbor)].append(new_path[1:-1] if len(new_path) > 2 else [])
                
                queue.append(new_path)

    return paths

# Store the intermediate nodes of all shortest paths
def calculate_all_shortest_paths_intermediate_nodes(graph, all_nodes):
    all_paths_intermediate_nodes = defaultdict(list)
    for node in all_nodes:
        paths_from_node = bfs_shortest_paths(graph, node)
        all_paths_intermediate_nodes.update(paths_from_node)
    return all_paths_intermediate_nodes

all_paths_intermediate_nodes = calculate_all_shortest_paths_intermediate_nodes(adj_list, all_nodes)

# Between centrality calculation
def calculate_betweenness_centrality(all_paths_intermediate_nodes):
    node_contributions = defaultdict(float)

    for _, paths in all_paths_intermediate_nodes.items():
        for intermediates in paths:
            if len(intermediates) > 0: 
                contribution = 1 / len(paths)
                for node in set(intermediates): 
                    node_contributions[node] += contribution

    return node_contributions

betweenness_centrality = calculate_betweenness_centrality(all_paths_intermediate_nodes)

value = 2707*2706

betweenness_file_path = 'C:\\Users\\ABHINANDAN\\Desktop\\complex\\cora\\centralities\\betweenness.txt'
with open(betweenness_file_path, 'w+') as file:
    for node, centrality in sorted(betweenness_centrality.items(), key=lambda x: x[1], reverse=True):
        file.write(f"{node} {centrality/value:.6f}\n")