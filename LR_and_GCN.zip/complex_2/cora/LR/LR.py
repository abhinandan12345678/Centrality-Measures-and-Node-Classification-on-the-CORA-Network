import networkx as nx
import numpy as np
from collections import defaultdict
from gensim.models import Word2Vec
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from sklearn.preprocessing import LabelEncoder

# Creation of Adjacency List of the Graph
def create_adj_list_from_cites_file(file_path):
    adj_list = {}
    with open(file_path, 'r') as file:
        for line in file:
            target, source = line.strip().split()
            target = int(target)
            source = int(source)
            if source not in adj_list:
                adj_list[source] = []
            if target not in adj_list:
                adj_list[target] = []

            adj_list[source].append(target)

    return adj_list

# Adjust the nodes with zero outdegree
def adjust_adj_list_for_zero_outdegree_nodes(adj_list):
    no_outgoing = [node for node, targets in adj_list.items() if len(targets) == 0]

    for node in no_outgoing:
        for source, targets in adj_list.items():
            if node in targets:
                if node not in adj_list:
                    adj_list[node] = []
                adj_list[node].append(source)
    
    return adj_list

# Store the node ids in a list
def get_all_nodes_from_adj_list(adj_list):
    all_nodes_set = set()
    for source in adj_list.keys():
        all_nodes_set.add(source)

    for targets in adj_list.values():
        all_nodes_set.update(targets)

    all_nodes_list = list(all_nodes_set)
    return all_nodes_list

file_path = 'cora.cites'
adj_list_primal = create_adj_list_from_cites_file(file_path)
adj_list = adjust_adj_list_for_zero_outdegree_nodes(adj_list_primal)
all_nodes = get_all_nodes_from_adj_list(adj_list)

def create_directed_graph_from_adj_list(adj_list):
    G = nx.DiGraph()
    for source, targets in adj_list.items():
        for target in targets:
            G.add_edge(source, target)
    return G

G = create_directed_graph_from_adj_list(adj_list)

def compute_probabilities(graph, probs, p, q):
    G = graph
    for source_node in G.nodes():
        for current_node in G.neighbors(source_node):
            probs_ = list()
            for destination in G.neighbors(current_node):

                if source_node == destination:
                    prob_ = G[current_node][destination].get('weight',1) * (1/p)
                elif destination in G.neighbors(source_node):
                    prob_ = G[current_node][destination].get('weight',1)
                else:
                    prob_ = G[current_node][destination].get('weight',1) * (1/q)
                
                probs_.append(prob_)
            
            probs[source_node]['probabilities'][current_node] = probs_/np.sum(probs_)
    
    return probs

def generate_random_walks(graph, probs, max_walks, walk_len):
    G = graph
    walks = list()
    for start_node in G.nodes():
        for i in range(max_walks):
            walk = [start_node]
            walk_options = list(G[start_node])
            if len(walk_options) == 0:
                break
            first_step = np.random.choice(walk_options)
            walk.append(first_step)

            for k in range(walk_len - 2):
                walk_options = list(G[walk[-1]])
                if len(walk_options) == 0:
                    break
                probabilities = probs[walk[-2]]['probabilities'][walk[-1]]
                next_step = np.random.choice(walk_options, p=probabilities)
                walk.append(next_step)
            
            walks.append(walk)
    np.random.shuffle(walks)
    walks = [list(map(str, walk)) for walk in walks]

    return walks

def Node2Vec(generated_walks, window_size, embedding_vector_size):
    model = Word2Vec(sentences = generated_walks, window = window_size, vector_size = embedding_vector_size)
    return model.wv

probs = defaultdict(dict)
for node in G.nodes():
    probs[node]['probabilities'] = dict()

cp = compute_probabilities(G, probs, 1, 1)
walks = generate_random_walks(G, cp, 5, 10)

n2v_emb = Node2Vec(walks, 20, 100)

node_labels = {}
source_nodes = set()
source_nodes_test = set()
error_content = None
error_cites = None

try:
    with open('cora.content', 'r') as file:
        for line in file:
            parts = line.strip().split('\t')
            node_id = int(parts[0]) 
            label = parts[-1]
            node_labels[node_id] = label
except Exception as e:
    error_content = str(e)

try:
    with open('cora_train.cites', 'r') as file:
        for line in file:
            parts = line.strip().split()
            source_node = int(parts[1])
            source_nodes.add(source_node)
except Exception as e:
    error_cites = str(e)

try:
    with open('cora_test.cites', 'r') as file:
        for line in file:
            parts = line.strip().split()
            source_node_test = int(parts[1])
            source_nodes_test.add(source_node_test)
except Exception as e:
    error_cites = str(e)

source_nodes_labels = {node: node_labels.get(node) for node in source_nodes if node in node_labels}
source_nodes_labels_test = {node: node_labels.get(node) for node in source_nodes_test if node in node_labels}

label_encoder = LabelEncoder()
label_encoder.fit(list(source_nodes_labels.values()))
label_encoder.fit(list(source_nodes_labels_test.values()))

X = []  # Feature matrix (node embeddings)
X_test = []
y = []  # Encoded labels
y_test = []

for node_id, label in source_nodes_labels.items():
    if str(node_id) in n2v_emb.key_to_index:
        X.append(n2v_emb[str(node_id)])
        y.append(label_encoder.transform([label])[0])

for node_id, label in source_nodes_labels_test.items():
    if str(node_id) in n2v_emb.key_to_index:
        X_test.append(n2v_emb[str(node_id)])
        y_test.append(label_encoder.transform([label])[0])

X = np.array(X)
y = np.array(y)
X_test = np.array(X_test)
y_test = np.array(y_test)

model = LogisticRegression(max_iter=1000)
model.fit(X, y)

# Evaluate the model
y_pred = model.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)
precision = precision_score(y_test, y_pred, average='macro')
recall = recall_score(y_test, y_pred, average='macro')
f1 = f1_score(y_test, y_pred, average='macro')

metrics_content = f"""Accuracy: {accuracy}
Precision: {precision}
Recall: {recall}
F1 Score: {f1}
"""

file_path = "lr_metrics.txt"

with open(file_path, 'w+') as file:
    file.write(metrics_content)

print(f"Metrics written to {file_path}")
